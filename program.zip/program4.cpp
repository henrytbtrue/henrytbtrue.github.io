#include <bits/stdc++.h>
using namespace std;

const int N=1e5+5;
const int mod=1e9+7;

int n;
int a[N];

int num=0,ans=0;

void ___() {
    num=0;
    scanf("%d",&n);
    for(int i=1;i<=n;++i) scanf("%d",&a[i]);
    for(int i=1;i<=n;++i) {
        bool flag=0;
        for(int j=31;j>=0;--j) {
            if(!(a[i]&(1<<j)) && (num&(1<<j))) {
                break;
            }
            if((a[i]&(1<<j)) && !(num&(1<<j))) {
                flag=1;
                break;
            }
        }
        if(flag) num=a[i];
    }
    for(int i=1;i<=n;++i) {
        for(;a[i]!=num;++a[i]) ans=(ans+1)%mod;
    }
    printf("%d\n",ans);
}

int main() {
    ___();
    ___();
    ___();
    ___();
    ___();
    
    ___();
    ___();
    ___();
    ___();
    ___();
    return 0;
}