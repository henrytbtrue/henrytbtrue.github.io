#include <bits/stdc++.h>

using namespace std;

long long func(long long a,long long b) {
	if(a<b) swap(a,b);
	if(b==0) return a;
	return func(b,a-b);
}

void __() {
	long long a,b;
	scanf("%lld%lld",&a,&b);
	printf("%lld\n",func(a,b));
}

int main() {
	__();
	__();
	__();
	__();
	__();
	
	__();
	__();
	__();
	__();
	__();
	return 0;
}
