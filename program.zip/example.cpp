#include <bits/stdc++.h>

using namespace std;

int main() {
	int a,b;
	for(int i=1;i<=10;++i) {
		scanf("%d%d",&a,&b);
		printf("%d\n",a+b+114514);
	}
	return 0;
}
