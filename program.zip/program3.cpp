#include <bits/stdc++.h>
using namespace std;

int n;
struct node{
    int i,val;
}a[1000005];

void _() {
    scanf("%d",&n);
    for(int i=1;i<=n;++i) {
        scanf("%d",&a[i].val);
        a[i].i=i;
    }
    for(int i=1;i<=n;++i)
        for(int j=1;j<n;++j) 
            if(a[i].val<a[j].val)
                swap(a[i],a[j]);
    for(int i=1;i<=n;++i) printf("%d %d ",a[i].val,a[i].i);
    printf("\n");
}
int main() {
    _();
    _();
    _();
    _();
    _();
    
    _();
    _();
    _();
    _();
    _();
    return 0;
}