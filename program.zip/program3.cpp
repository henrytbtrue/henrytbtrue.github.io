#include <bits/stdc++.h>
using namespace std;

int n,k;
struct node{
    int i,val;
}a[1000005];

void _() {
    scanf("%d%d",&n,&k);
    for(int i=1;i<=n;++i) {
        scanf("%d",&a[i].val);
        a[i].i=i;
    }
    for(int i=1;i<=n;++i)
        for(int j=1;j<n;++j) 
            if(a[i].val<a[j].val)
                swap(a[i],a[j]);
    printf("%d %d ",a[k].val,a[k].i);
    printf("\n");
}
int main() {
    _();
    _();
    _();
    _();
    _();
    
    _();
    _();
    _();
    _();
    _();
    return 0;
}