#include <bits/stdc++.h>

using namespace std;
const int p=1e9+7;
void __() {
	int a,b;
	int ans=0;
	scanf("%d%d",&a,&b);
	for(int i=a;i<=b;++i)
		for(int j=a;j<=b;++j)
			ans=(ans+1)%p;
	printf("%d\n",ans);
}

int main() {
	__();
	__();
	__();
	__();
	__();
	
	__();
	__();
	__();
	__();
	__();
	return 0;
}
